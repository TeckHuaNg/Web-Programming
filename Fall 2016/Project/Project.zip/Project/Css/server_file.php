<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Edit Payment Information - PayPal™</title>
        <link rel="stylesheet" href="styles.css" />
    </head>
    <body>
        <h1>PayPal™</h1>
        <h2>Settings Updated</h2>
<?php
    /* All form elements must be checked - that required information is present and that all form data
    is in the correct format. Security checks must also be made before database queries are made */
    $fname = $_GET['fname'];
    $lname = $_GET['lname'];
    // Output a friendly message to confirm that everything went well
    echo('<p>Thank You, '.$fname.'&nbsp;'.$lname.' &mdash; your settings have been saved.</p>');
?>
    </body>
</html>
 